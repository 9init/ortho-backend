export class CreateScanDto {}
