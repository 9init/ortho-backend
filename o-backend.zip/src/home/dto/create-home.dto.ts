export class CreateHomeDto {}
